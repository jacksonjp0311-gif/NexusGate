"""Core contracts for NEXUS GATE."""
